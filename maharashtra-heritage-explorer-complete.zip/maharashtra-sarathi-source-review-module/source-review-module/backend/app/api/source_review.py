from fastapi import APIRouter,Depends,HTTPException,Query
from pydantic import BaseModel,Field
from sqlalchemy import select,func
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.security import admin
from app.models.entities import User
from app.models.source_review import SourceReviewItem,ReviewDecision,ReviewAuditEvent
from app.services.source_review import decide
class DecisionIn(BaseModel):decision:str;reason_code:str;comment:str=Field(min_length=3,max_length=3000);replacement_value:dict|None=None;expected_version:int
class AssignIn(BaseModel):reviewer_id:int;expected_version:int
router=APIRouter(prefix='/api/v1/admin/source-reviews',tags=['Source review'])
@router.get('')
def queue(status:str='PENDING',assigned_to:int|None=None,priority_min:int=0,limit:int=Query(50,ge=1,le=100),offset:int=0,_:User=Depends(admin),db:Session=Depends(get_db)):
 q=select(SourceReviewItem).where(SourceReviewItem.status==status,SourceReviewItem.priority>=priority_min)
 if assigned_to is not None:q=q.where(SourceReviewItem.assigned_to==assigned_to)
 items=db.scalars(q.order_by(SourceReviewItem.priority.desc(),SourceReviewItem.created_at).offset(offset).limit(limit)).all();total=db.scalar(select(func.count()).select_from(q.subquery()))
 return {'items':items,'total':total,'limit':limit,'offset':offset}
@router.get('/summary')
def summary(_:User=Depends(admin),db:Session=Depends(get_db)):return {'counts':dict(db.execute(select(SourceReviewItem.status,func.count()).group_by(SourceReviewItem.status)).all())}
@router.get('/{item_id}')
def detail(item_id:int,_:User=Depends(admin),db:Session=Depends(get_db)):
 item=db.get(SourceReviewItem,item_id)
 if not item:raise HTTPException(404,'Not found')
 return {'item':item,'history':db.scalars(select(ReviewDecision).where(ReviewDecision.item_id==item_id).order_by(ReviewDecision.decided_at.desc())).all()}
@router.post('/{item_id}/decision')
def save_decision(item_id:int,x:DecisionIn,u:User=Depends(admin),db:Session=Depends(get_db)):
 item=db.get(SourceReviewItem,item_id)
 if not item:raise HTTPException(404,'Not found')
 return decide(db,item,u,x.decision,x.reason_code,x.comment,x.replacement_value,x.expected_version)
@router.get('/{item_id}/audit')
def audit(item_id:int,_:User=Depends(admin),db:Session=Depends(get_db)):return db.scalars(select(ReviewAuditEvent).where(ReviewAuditEvent.entity_id==item_id).order_by(ReviewAuditEvent.created_at)).all()
