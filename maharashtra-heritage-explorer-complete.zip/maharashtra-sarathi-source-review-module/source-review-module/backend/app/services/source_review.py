from datetime import datetime
from fastapi import HTTPException
from app.models.source_review import SourceReviewItem,ReviewDecision,ReviewAuditEvent
ALLOWED={'APPROVE':'APPROVED','REJECT':'REJECTED','REQUEST_CHANGES':'CHANGES_REQUESTED','MARK_CONFLICT':'CONFLICTING'}
def decide(db,item,reviewer,decision,reason_code,comment,replacement_value,expected_version):
 if decision not in ALLOWED:raise HTTPException(400,'Unsupported decision')
 if item.status in {'APPROVED','REJECTED'}:raise HTTPException(409,'Final decision already exists')
 if item.version!=expected_version:raise HTTPException(409,'Item changed; refresh before deciding')
 if not reason_code.strip() or not comment.strip():raise HTTPException(422,'Reason code and comment are required')
 before={'status':item.status,'version':item.version,'value':item.proposed_value}
 item.status=ALLOWED[decision];item.version+=1;item.updated_at=datetime.utcnow()
 db.add(ReviewDecision(item_id=item.id,reviewer_id=reviewer.id,decision=decision,reason_code=reason_code,comment=comment,replacement_value=replacement_value,decision_version=item.version))
 db.add(ReviewAuditEvent(actor_id=reviewer.id,entity_type='source_review_item',entity_id=item.id,action=decision,before_json=before,after_json={'status':item.status,'version':item.version,'value':replacement_value or item.proposed_value}))
 db.commit();db.refresh(item);return item
