# Integration
1. Copy backend files into the existing FastAPI project.
2. Import the model before `Base.metadata.create_all`, or convert `sql/001_source_review.sql` into an Alembic migration.
3. Include the router: `app.include_router(source_review.router)`.
4. Copy the Next.js page to `frontend/app/admin/source-review/page.tsx`.
5. Require admin JWT/RBAC. Do not expose the queue publicly.
6. Update public queries and the RAG indexer to consume only approved/verified claims.

## State machine
PENDING -> APPROVED | REJECTED | CHANGES_REQUESTED | CONFLICTING

## Approval checklist
- Source publisher and URL exist.
- Immutable snapshot/hash is retained.
- Evidence excerpt supports the exact claim.
- Historical fact, religious tradition and live visitor data are classified separately.
- Reuse/licence conditions pass.
- No higher-authority conflict remains.
- Marathi and English carry the same factual meaning.
- Volatile facts include expiry/refresh metadata.

## Safety controls
Optimistic locking returns HTTP 409 on stale versions. Every decision requires reason/comment and creates append-only decision and audit rows. Bulk approvals should require a separate publisher role and step-up authentication.
