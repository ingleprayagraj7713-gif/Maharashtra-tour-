from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.db.session import get_db
from app.core.security import admin,current_user
from app.models.entities import User
from app.models.media import MediaAsset,RagDocument
from app.schemas.api import MediaReviewIn
from app.services.licensing import assess
router=APIRouter(prefix="/api/v1")
@router.post("/admin/media/review")
def review_media(x:MediaReviewIn,_:User=Depends(admin),db:Session=Depends(get_db)):
 d=assess(x.license_code,x.creator,x.original_source_url,x.place_verified)
 asset=MediaAsset(**x.model_dump(),moderation_status=d.status)
 db.add(asset);db.commit();db.refresh(asset)
 return {"id":asset.id,"allowed":d.allowed,"status":d.status,"reason":d.reason}
@router.get("/media/{place_id}")
def approved_media(place_id:int,db:Session=Depends(get_db)):
 return db.scalars(select(MediaAsset).where(MediaAsset.place_id==place_id,MediaAsset.moderation_status=="APPROVED")).all()
@router.get("/rag/status")
def rag_status():return {"name":"Maharashtra Sarathi","mode":"verified-open-content-only","rules":["approved licence","verified source","claim provenance","citation required","refuse unsupported answer"]}
