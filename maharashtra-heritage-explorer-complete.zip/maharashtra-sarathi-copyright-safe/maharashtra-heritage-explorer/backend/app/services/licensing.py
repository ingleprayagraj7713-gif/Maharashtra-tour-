from dataclasses import dataclass
ALLOWED={"CC0","PUBLIC_DOMAIN","CC_BY_4_0","CC_BY_SA_4_0","GODL_INDIA","OWNED","EXPLICIT_PERMISSION"}
BLOCKED={"UNKNOWN","ALL_RIGHTS_RESERVED","FAIR_USE","CC_BY_NC","CC_BY_ND"}
@dataclass
class Decision:
    allowed:bool
    status:str
    reason:str
def assess(license_code:str,creator:str|None,source_url:str|None,place_verified:bool)->Decision:
    code=license_code.upper().strip()
    if code not in ALLOWED:return Decision(False,"BLOCKED_LICENSE",f"Licence {code or 'UNKNOWN'} is not approved")
    if not source_url and code not in {"OWNED"}:return Decision(False,"BLOCKED_SOURCE_MISSING","Original source URL is required")
    if code in {"CC_BY_4_0","CC_BY_SA_4_0","EXPLICIT_PERMISSION"} and not creator:return Decision(False,"BLOCKED_ATTRIBUTION","Creator is required")
    if not place_verified:return Decision(False,"BLOCKED_IMAGE_IDENTITY","Place identity has not been verified")
    return Decision(True,"APPROVED","Licence, attribution and identity checks passed")
