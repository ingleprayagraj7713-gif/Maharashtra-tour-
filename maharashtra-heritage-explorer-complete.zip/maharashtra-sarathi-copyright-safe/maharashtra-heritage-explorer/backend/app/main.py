from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.db.session import Base,engine
from app.api.routes import router
from app.api.licensing_routes import router as licensing_router
from app.models import media
Base.metadata.create_all(bind=engine)
app=FastAPI(title="Maharashtra Heritage Explorer API",version="1.0.0",docs_url="/docs")
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origins.split(","),allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(router)
app.include_router(licensing_router)
@app.get("/health")
def health():return {"status":"ok"}
