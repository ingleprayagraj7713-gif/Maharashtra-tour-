from sqlalchemy import String,Text,DateTime,ForeignKey,Boolean
from sqlalchemy.orm import Mapped,mapped_column
from datetime import datetime
from app.db.session import Base
class MediaAsset(Base):
 __tablename__="media_assets"
 id:Mapped[int]=mapped_column(primary_key=True)
 place_id:Mapped[int|None]=mapped_column(ForeignKey("places.id"))
 title:Mapped[str]=mapped_column(String(240))
 storage_key:Mapped[str]=mapped_column(Text)
 original_source_url:Mapped[str|None]=mapped_column(Text)
 creator:Mapped[str|None]=mapped_column(String(240))
 license_code:Mapped[str]=mapped_column(String(60))
 license_url:Mapped[str|None]=mapped_column(Text)
 attribution_text:Mapped[str|None]=mapped_column(Text)
 content_hash:Mapped[str]=mapped_column(String(64),unique=True)
 place_verified:Mapped[bool]=mapped_column(Boolean,default=False)
 moderation_status:Mapped[str]=mapped_column(String(40),default="PENDING")
 retrieved_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class RagDocument(Base):
 __tablename__="rag_documents"
 id:Mapped[int]=mapped_column(primary_key=True)
 place_id:Mapped[int|None]=mapped_column(ForeignKey("places.id"))
 source_id:Mapped[int]=mapped_column(ForeignKey("sources.id"))
 title:Mapped[str]=mapped_column(String(300))
 language:Mapped[str]=mapped_column(String(5))
 text_hash:Mapped[str]=mapped_column(String(64),unique=True)
 license_code:Mapped[str]=mapped_column(String(60))
 verification_status:Mapped[str]=mapped_column(String(40),default="PENDING")
 indexed_at:Mapped[datetime|None]=mapped_column(DateTime)
