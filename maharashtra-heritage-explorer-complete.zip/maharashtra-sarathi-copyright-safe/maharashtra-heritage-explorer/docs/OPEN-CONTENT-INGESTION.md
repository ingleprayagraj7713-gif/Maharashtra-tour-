# Open-content ingestion workflow
1. Register source and licence.
2. Save immutable evidence snapshot and SHA-256.
3. Extract claims, never copy long prose.
4. Review historical accuracy independently.
5. Review licence and attribution.
6. Verify image-place identity.
7. Publish approved record.
8. Index only approved RAG documents.
9. Re-check stale or changed sources.
