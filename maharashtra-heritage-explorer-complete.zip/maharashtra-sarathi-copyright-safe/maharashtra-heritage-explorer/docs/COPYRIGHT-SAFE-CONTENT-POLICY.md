# Copyright-safe content policy

## Default-deny rule
No text, image, video, map, dataset or RAG document is published until both provenance and reuse rights are recorded.

## Allowed media
- Original assets owned by the project
- CC0 / Public Domain
- CC BY 4.0 with attribution
- CC BY-SA 4.0 after ShareAlike compatibility review
- GODL-India datasets under the applicable dataset terms
- Written permission retained as evidence

## Blocked automatically
- Unknown licence
- All Rights Reserved without permission
- Fair-use-only content
- NonCommercial content for a potentially commercial site
- NoDerivatives assets that need editing
- Misidentified place imagery

## TASL attribution
Store Title, Author, Source and Licence for every reused media item.

## RAG
Only approved documents are chunked/indexed. Store source ID, licence, language, text hash, retrieved timestamp and verification status. Every historical answer requires citations. Live routes, weather, timings and fees must come from live/official providers and never from historical embeddings.
