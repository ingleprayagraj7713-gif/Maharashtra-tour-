# महाराष्ट्र गड-किल्ले व देवस्थान एक्सप्लोरर

Next.js + FastAPI application without infrastructure/IaC. Marathi is the default language and English is available instantly.

## Run frontend
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:3000.

## Run API (optional)
```bash
cd backend
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Data policy
Sample records include provenance. Images in this demo are remote placeholders from Unsplash and must be replaced with licensed, place-accurate images before production. Live timings, fees, weather, hotels and routes are deliberately not fabricated.

## Copyright-safe edition
This edition removes remote third-party place images. Place cards use local visual placeholders until an asset passes licence, attribution and identity review. See `docs/COPYRIGHT-SAFE-CONTENT-POLICY.md` and `/licensing`.

The bundled logo and homepage concept were generated with Microsoft Copilot. Visuals in this project were generated with Microsoft Copilot.
