# Security baseline
- No secrets in Git or Docker layers; AWS Secrets Manager + task IAM roles.
- TLS only; HSTS, secure cookies, CSRF protection, OAuth state/nonce, strict redirect allowlist.
- S3 Block Public Access; presigned uploads; malware/content moderation pipeline.
- Rate-limit auth, search, reviews and AI endpoints.
- Validate uploads by MIME/signature/size; strip dangerous metadata where appropriate.
- PostgreSQL encryption, PITR, least-privilege DB roles, parameterized ORM access.
- Trivy image/IaC scans; dependency/SBOM scan; signed immutable images.
- AI: prompt-injection boundary, retrieval allowlist, citations, PII filtering, token/rate budgets.
