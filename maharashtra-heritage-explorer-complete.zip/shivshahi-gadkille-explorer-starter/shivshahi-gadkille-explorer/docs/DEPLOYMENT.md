# AWS deployment
Use separate AWS accounts for dev/stage/prod. Bootstrap an encrypted/versioned S3 Terraform-state bucket plus DynamoDB lock strategy supported by your Terraform version, configure Route53 + ACM, create ECR repositories, build immutable images, deploy RDS PostgreSQL in private subnets, then ECS Fargate services behind an ALB. Put CloudFront in front of the public origin and restrict origins appropriately. Store credentials in Secrets Manager. Run migrations as a one-off ECS task before service rollout. Enable ALB/ECS/RDS/CloudFront logs and alarms.

Use at least two AZs in production. Keep ECS tasks and RDS private. Only the ALB is internet-facing. Use WAF for the public edge.
