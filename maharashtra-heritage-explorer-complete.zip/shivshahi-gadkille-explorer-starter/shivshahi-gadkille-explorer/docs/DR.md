# Disaster recovery
Target baseline: RPO <= 15 minutes, RTO <= 4 hours. Enable RDS automated backups/PITR, S3 versioning and cross-region replication for irreplaceable user media, ECR replication for critical images, and Terraform-controlled rebuilds. Quarterly restore tests are mandatory; measure actual RTO/RPO.
