from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from .seed import FORTS
app=FastAPI(title="Shivshahi Gadkille Explorer API",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:3000"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
@app.get("/health")
def health(): return {"status":"ok"}
@app.get("/api/v1/forts")
def forts(q:str|None=Query(None), district:str|None=None):
    data=FORTS
    if q: data=[x for x in data if q.lower() in (x["name_en"]+" "+x["name_mr"]).lower()]
    if district: data=[x for x in data if x.get("district","").lower()==district.lower()]
    return {"items":data,"count":len(data)}
@app.get("/api/v1/forts/{slug}")
def fort(slug:str):
    from fastapi import HTTPException
    x=next((f for f in FORTS if f["slug"]==slug),None)
    if not x: raise HTTPException(404,"Fort not found")
    return x
@app.post("/api/v1/ai/chat")
def ai_chat(payload:dict):
    return {"message":"AI Maharaj RAG adapter is configured as an integration boundary. Connect a verified corpus and model provider before production use.","language":payload.get("language","mr")}
