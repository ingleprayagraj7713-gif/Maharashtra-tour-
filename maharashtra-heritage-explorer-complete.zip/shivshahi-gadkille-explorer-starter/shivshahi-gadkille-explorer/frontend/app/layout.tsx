export const metadata={title:"शिवशाही गडकिल्ले एक्सप्लोरर | Shivshahi Gadkille Explorer",description:"महाराष्ट्रातील गड-किल्ले, इतिहास आणि सुरक्षित प्रवास माहिती."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="mr"><body style={{margin:0,fontFamily:"system-ui",background:"#fff8ed",color:"#351c0c"}}>{children}</body></html>}
