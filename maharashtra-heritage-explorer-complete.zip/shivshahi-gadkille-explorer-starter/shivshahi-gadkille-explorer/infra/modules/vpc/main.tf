resource "aws_vpc" "this" { cidr_block="10.20.0.0/16" enable_dns_support=true enable_dns_hostnames=true tags={Name="shivshahi-${var.environment}"} }
resource "aws_subnet" "public_a" { vpc_id=aws_vpc.this.id cidr_block="10.20.0.0/20" availability_zone="ap-south-1a" map_public_ip_on_launch=true }
resource "aws_subnet" "private_a" { vpc_id=aws_vpc.this.id cidr_block="10.20.32.0/20" availability_zone="ap-south-1a" }
