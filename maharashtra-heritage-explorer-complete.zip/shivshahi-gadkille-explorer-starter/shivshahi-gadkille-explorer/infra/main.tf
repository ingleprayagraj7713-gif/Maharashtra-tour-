module "vpc" { source="./modules/vpc" environment=var.environment }
# Add production modules for ECR, ALB, ECS, RDS, S3, IAM, CloudFront, Route53, ACM and monitoring using remote state and environment-specific tfvars.
