variable "aws_region" { default="ap-south-1" }
variable "environment" { default="prod" }
variable "domain_name" { type=string }
