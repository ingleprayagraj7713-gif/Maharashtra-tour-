# शिवशाही गडकिल्ले एक्सप्लोरर | Shivshahi Gadkille Explorer

Production-oriented monorepo starter for a bilingual Maharashtra fort tourism platform.

## Stack
- Web: Next.js + TypeScript + Tailwind CSS
- API: FastAPI + SQLAlchemy + PostgreSQL
- AI: RAG integration boundary for LangChain/OpenAI/OpenSearch or Chroma
- Auth: Auth.js/NextAuth integration boundary
- Storage: S3
- Infra: AWS ECS Fargate, ALB, RDS, S3, ECR, CloudFront, Route53, ACM, CloudWatch, Secrets Manager, SNS
- IaC: Terraform
- CI/CD: Jenkins

## Important data rule
Historical facts, opening hours, entry fees, weather, routes, lodging and emergency services are modeled as sourced/versioned data. Do not publish unverified generated values. Ingest authoritative datasets and retain source URL, retrieved_at and verification_status.

## Local run
1. Copy `.env.example` to `.env`.
2. `docker compose up --build`
3. API docs: http://localhost:8000/docs
4. Web: http://localhost:3000

## Production rollout
See `docs/DEPLOYMENT.md`, `docs/SECURITY.md`, `docs/DR.md`, and `docs/COST.md`.
