# Completed application modules

## Frontend
- Fort/temple catalogue, search, filters and details
- Marathi/English core experience
- Provenance/source display
- Community submission UI
- Events UI
- Fort Passport badges
- Planner UI
- AI Maharaj boundary
- Dashboard
- Education catalogue
- Login form
- Admin moderation dashboard

## Backend
- JWT register/login
- SQLAlchemy DB layer (SQLite local, PostgreSQL-ready)
- Places, reviews, favorites, dashboard, community and events APIs
- Planner and AI integration boundaries
- Admin moderation queue
- Provenance Source/Claim models
- Seed and health test

## Deliberately provider-dependent
Google Maps, weather, hotel availability, email delivery, OAuth, S3 uploads and LLM/RAG require credentials and external provider configuration. The code does not fabricate those responses.
