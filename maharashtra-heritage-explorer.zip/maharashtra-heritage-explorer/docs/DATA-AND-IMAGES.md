# Data and images workflow
1. Register official source.
2. Archive raw response in immutable object storage.
3. Extract claims independently.
4. Associate every claim with source URL, retrieved date and content hash.
5. Resolve conflicts through admin review.
6. Publish only verified historical claims.
7. Retrieve weather, maps, hotel availability, opening hours and fees from live/official APIs.
8. Store image creator, licence, source URL, exact subject/place, capture date and moderation state.

The included Unsplash images are visual placeholders, not asserted to depict each named place. Replace them before publication with correctly licensed and verified images.
