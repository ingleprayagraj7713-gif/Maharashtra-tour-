import json
from pathlib import Path
from app.db.session import SessionLocal,Base,engine
from app.models.entities import Place,User
from app.core.security import hash_password
Base.metadata.create_all(bind=engine)
data=json.loads((Path(__file__).parents[2]/"frontend/data/places.json").read_text(encoding="utf-8"))
with SessionLocal() as db:
 if not db.query(User).filter_by(email="admin@example.com").first():db.add(User(email="admin@example.com",name="Admin",password_hash=hash_password("ChangeMe123!"),role="admin"))
 for p in data:
  if not db.query(Place).filter_by(slug=p["slug"]).first():db.add(Place(slug=p["slug"],place_type=p["type"],name_mr=p["name_mr"],name_en=p["name_en"],district_mr=p["district_mr"],district_en=p["district_en"],category_mr=p["category_mr"],category_en=p["category_en"],summary_mr=p["summary_mr"],summary_en=p["summary_en"],history_mr=p["history_mr"],history_en=p["history_en"],height=p.get("height"),difficulty=p.get("difficulty"),image_url=p.get("image"),published=True))
 db.commit()
print("Seed complete. Change the default admin password immediately.")
