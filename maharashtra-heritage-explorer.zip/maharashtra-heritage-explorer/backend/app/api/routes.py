from fastapi import APIRouter,Depends,HTTPException,Query
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.db.session import get_db
from app.models.entities import *
from app.schemas.api import *
from app.core.security import *
router=APIRouter(prefix="/api/v1")
@router.post("/auth/register",response_model=TokenOut)
def register(x:RegisterIn,db:Session=Depends(get_db)):
 if db.scalar(select(User).where(User.email==x.email)):raise HTTPException(409,"Email already registered")
 u=User(email=x.email,name=x.name,password_hash=hash_password(x.password));db.add(u);db.commit();db.refresh(u);return TokenOut(access_token=token(u.id))
@router.post("/auth/login",response_model=TokenOut)
def login(x:LoginIn,db:Session=Depends(get_db)):
 u=db.scalar(select(User).where(User.email==x.email))
 if not u or not verify_password(x.password,u.password_hash):raise HTTPException(401,"Invalid credentials")
 return TokenOut(access_token=token(u.id))
@router.get("/places")
def places(place_type:str|None=None,district:str|None=None,q:str|None=None,limit:int=Query(24,le=100),offset:int=0,db:Session=Depends(get_db)):
 s=select(Place).where(Place.published==True)
 if place_type:s=s.where(Place.place_type==place_type)
 if district:s=s.where(Place.district_en.ilike(f"%{district}%"))
 if q:s=s.where((Place.name_en.ilike(f"%{q}%"))|(Place.name_mr.ilike(f"%{q}%")))
 rows=db.scalars(s.offset(offset).limit(limit)).all();return {"items":rows,"count":len(rows)}
@router.get("/places/{slug}")
def place(slug:str,db:Session=Depends(get_db)):
 x=db.scalar(select(Place).where(Place.slug==slug,Place.published==True))
 if not x:raise HTTPException(404,"Place not found")
 return x
@router.post("/reviews")
def review(x:ReviewIn,u:User=Depends(current_user),db:Session=Depends(get_db)):
 r=Review(user_id=u.id,**x.model_dump());db.add(r);db.commit();return {"status":"pending","id":r.id}
@router.get("/reviews/{place_id}")
def reviews(place_id:int,db:Session=Depends(get_db)):return db.scalars(select(Review).where(Review.place_id==place_id,Review.status=="approved")).all()
@router.post("/favorites/{place_id}")
def favorite(place_id:int,u:User=Depends(current_user),db:Session=Depends(get_db)):
 if not db.scalar(select(Favorite).where(Favorite.user_id==u.id,Favorite.place_id==place_id)):db.add(Favorite(user_id=u.id,place_id=place_id));db.commit()
 return {"saved":True}
@router.get("/dashboard")
def dashboard(u:User=Depends(current_user),db:Session=Depends(get_db)):
 return {"user":{"name":u.name,"email":u.email},"favorites":db.scalars(select(Favorite).where(Favorite.user_id==u.id)).all(),"visits":db.scalars(select(Visit).where(Visit.user_id==u.id)).all()}
@router.get("/community")
def posts(db:Session=Depends(get_db)):return db.scalars(select(CommunityPost).where(CommunityPost.status=="approved").order_by(CommunityPost.created_at.desc())).all()
@router.post("/community")
def post(x:PostIn,u:User=Depends(current_user),db:Session=Depends(get_db)):
 p=CommunityPost(user_id=u.id,**x.model_dump());db.add(p);db.commit();return {"status":"pending","id":p.id}
@router.get("/events")
def events(db:Session=Depends(get_db)):return db.scalars(select(Event).where(Event.published==True).order_by(Event.starts_at)).all()
@router.post("/planner")
def planner(x:PlannerIn):return {"origin":x.origin,"destination":x.destination,"note":"Connect Google Routes API for verified distance/time.","fuel_formula":"distance_km / mileage_kmpl * fuel_price_per_litre"}
@router.post("/ai/chat")
def chat(x:ChatIn):return {"answer":"AI Maharaj requires a configured verified RAG corpus and model provider.","language":x.language,"citations":[]}
@router.get("/admin/queue")
def queue(_:User=Depends(admin),db:Session=Depends(get_db)):return {"claims":db.scalars(select(Claim).where(Claim.status.in_(["candidate","conflicting"]))).all(),"reviews":db.scalars(select(Review).where(Review.status=="pending")).all(),"posts":db.scalars(select(CommunityPost).where(CommunityPost.status=="pending")).all()}
@router.patch("/admin/reviews/{review_id}/{decision}")
def moderate_review(review_id:int,decision:str,_:User=Depends(admin),db:Session=Depends(get_db)):
 if decision not in {"approved","rejected"}:raise HTTPException(400,"Invalid decision")
 r=db.get(Review,review_id)
 if not r:raise HTTPException(404,"Review not found")
 r.status=decision;db.commit();return {"status":decision}
