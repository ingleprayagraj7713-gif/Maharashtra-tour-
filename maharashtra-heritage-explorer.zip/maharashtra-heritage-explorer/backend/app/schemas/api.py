from pydantic import BaseModel,EmailStr,Field
from datetime import datetime
class RegisterIn(BaseModel):email:EmailStr;password:str=Field(min_length=8);name:str
class LoginIn(BaseModel):email:EmailStr;password:str
class TokenOut(BaseModel):access_token:str;token_type:str="bearer"
class ReviewIn(BaseModel):place_id:int;rating:int=Field(ge=1,le=5);body:str=Field(min_length=3,max_length=3000)
class PostIn(BaseModel):title:str=Field(min_length=3,max_length=240);body:str=Field(min_length=10,max_length=10000);place_id:int|None=None;image_url:str|None=None
class EventIn(BaseModel):title_mr:str;title_en:str;description_mr:str;description_en:str;starts_at:datetime;location:str;capacity:int=0
class PlannerIn(BaseModel):origin:str;destination:str;travel_date:str|None=None;vehicle_mileage_kmpl:float=15;fuel_price_per_litre:float=105
class ChatIn(BaseModel):message:str;language:str="mr"
