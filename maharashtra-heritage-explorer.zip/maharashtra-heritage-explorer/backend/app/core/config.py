from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    database_url:str="sqlite:///./heritage.db"
    secret_key:str="dev-only-change-me"
    access_token_expire_minutes:int=60
    cors_origins:str="http://localhost:3000"
    model_config=SettingsConfigDict(env_file=".env",extra="ignore")
settings=Settings()
