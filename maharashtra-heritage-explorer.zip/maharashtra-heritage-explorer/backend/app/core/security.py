from datetime import datetime,timedelta,timezone
from jose import jwt,JWTError
from passlib.context import CryptContext
from fastapi import Depends,HTTPException,status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.core.config import settings
from app.db.session import get_db
from app.models.entities import User
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto");oauth2=OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")
def hash_password(v):return pwd.hash(v)
def verify_password(v,h):return pwd.verify(v,h)
def token(user_id:int):return jwt.encode({"sub":str(user_id),"exp":datetime.now(timezone.utc)+timedelta(minutes=settings.access_token_expire_minutes)},settings.secret_key,algorithm="HS256")
def current_user(raw:str=Depends(oauth2),db:Session=Depends(get_db)):
 try:uid=int(jwt.decode(raw,settings.secret_key,algorithms=["HS256"])["sub"])
 except (JWTError,KeyError,ValueError):raise HTTPException(status.HTTP_401_UNAUTHORIZED,"Invalid token")
 u=db.get(User,uid)
 if not u or not u.active:raise HTTPException(401,"Inactive user")
 return u
def admin(u:User=Depends(current_user)):
 if u.role!="admin":raise HTTPException(403,"Admin access required")
 return u
