# महाराष्ट्र गड-किल्ले व देवस्थान एक्सप्लोरर

Next.js + FastAPI application. Marathi is the default language and English is available instantly.

## Run frontend
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:3000.

## Deploy to Amazon EKS

The manifests in `deploy/k8s` deploy two replicas of the Next.js frontend and FastAPI backend behind one NGINX ingress. These steps assume AWS CLI, `eksctl`, `kubectl`, Docker, and Helm are installed and configured for an AWS account. Run the commands in AWS CloudShell or another Bash shell with AWS permissions.

### 1. Set deployment values and create the cluster

Choose an AWS region and a unique EKS cluster name. The example creates a small two-node cluster; adjust the instance type and node count for your workload and budget.

```bash
export AWS_REGION=us-east-1
export CLUSTER_NAME=heritage-explorer
export AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

eksctl create cluster \
  --name "$CLUSTER_NAME" \
  --region "$AWS_REGION" \
  --nodes 2 \
  --node-type t3.large

aws eks update-kubeconfig --name "$CLUSTER_NAME" --region "$AWS_REGION"
```

### 2. Create ECR repositories and push the images

```bash
aws ecr create-repository --repository-name maharashtra-heritage-frontend --region "$AWS_REGION"
aws ecr create-repository --repository-name maharashtra-heritage-backend --region "$AWS_REGION"

aws ecr get-login-password --region "$AWS_REGION" |
  docker login --username AWS --password-stdin "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"

docker build -t maharashtra-heritage-frontend:latest ./frontend
docker tag maharashtra-heritage-frontend:latest "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/maharashtra-heritage-frontend:latest"
docker push "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/maharashtra-heritage-frontend:latest"

docker build -t maharashtra-heritage-backend:latest ./backend
docker tag maharashtra-heritage-backend:latest "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/maharashtra-heritage-backend:latest"
docker push "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/maharashtra-heritage-backend:latest"
```

### 3. Install the NGINX ingress controller

This provisions an internet-facing AWS Network Load Balancer for the ingress controller.

```bash
helm upgrade --install ingress-nginx ingress-nginx \
  --repo https://kubernetes.github.io/ingress-nginx \
  --namespace ingress-nginx --create-namespace \
  --set controller.service.annotations."service\.beta\.kubernetes\.io/aws-load-balancer-type"=nlb \
  --set controller.service.annotations."service\.beta\.kubernetes\.io/aws-load-balancer-scheme"=internet-facing

kubectl wait --namespace ingress-nginx \
  --for=condition=available deployment/ingress-nginx-controller \
  --timeout=5m
```

### 4. Configure backend secrets and images

Use an Amazon RDS PostgreSQL database for persistent production data. Supply its SQLAlchemy connection URL (`postgresql+psycopg://...`) and restrict its network access to the EKS cluster. Generate a unique signing key; do not commit credentials or secrets to the repository.

```bash
kubectl create namespace heritage
kubectl -n heritage create secret generic backend-secrets \
  --from-literal=database-url='postgresql+psycopg://USER:PASSWORD@RDS_ENDPOINT:5432/DB_NAME' \
  --from-literal=secret-key="$(openssl rand -hex 32)" \
  --from-literal=cors-origins='http://localhost:3000'
```

Replace the example database URL with your RDS values. Set `cors-origins` to the browser application's origin if it will call the API from a different origin. With the provided single-host ingress, frontend and API share an origin, so CORS is not needed for those requests. For HTTPS, configure TLS on the ingress before production use.

Edit `deploy/k8s/kustomization.yaml`: replace `ACCOUNT_ID` and `AWS_REGION` in both ECR image names with the values from step 1. Then deploy:

```bash
kubectl apply -k deploy/k8s
kubectl -n heritage rollout status deployment/backend
kubectl -n heritage rollout status deployment/frontend
kubectl -n heritage get ingress heritage
```

The namespace manifest is included in Kustomize; if `kubectl create namespace heritage` reported that it already exists, that is expected.

### 5. Open the site and verify

Get the ingress controller's load balancer hostname and use it to create a DNS record for your site:

```bash
INGRESS_HOST=$(kubectl -n ingress-nginx get service ingress-nginx-controller \
  -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
echo "Open http://$INGRESS_HOST"
```

Check the API at `/health` and interactive API docs at `/docs`. If you change a secret, restart the backend to load it:

```bash
kubectl -n heritage rollout restart deployment/backend
```

For production, configure HTTPS with a domain and certificate, restrict database ingress to the cluster, and use AWS Secrets Manager with the Secrets Store CSI Driver (or External Secrets Operator) rather than passing long-lived credentials through shell history.

## Run API (optional)
```bash
cd backend
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Data policy
Sample records include provenance. Images in this demo are remote placeholders from Unsplash and must be replaced with licensed, place-accurate images before production. Live timings, fees, weather, hotels and routes are deliberately not fabricated.
